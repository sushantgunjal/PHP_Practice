<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    protected $primaryKey = 'string';
    public $incrementing = false;
    protected $guarded = [];
    // protected $fillable = ['id', 'name'];
}
