<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Member;
use App\Models\Task;

class TaskController extends Controller
{
    //
    public function store($id, Request $request)
    {
        if (Team::where('id', $id)->exists() && Member::where('m_id', $request->assignee_id)->exists()) {
            $task = Task::create([
                't_id' => $id,
                'a_id' => $request->assignee_id,
                'titlle' =>$request->title,
                'description' =>$request->description,
                'status' =>$request->status,
            ]);
            return response()->json($task, 201);
        } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
        }
    }


    public function show($id)
    {
        if (Task::where('t_id', $id)->exists()) {
            //$team = Team::where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
            $task = Task::where([
                ['t_id', '=', $id],
                ['status', '=', 'to do']
            ])->get()->toJson(JSON_PRETTY_PRINT);
            return response($task, 200);
        } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
          }
        //return $team;
    }

    public function showtaskformembers($id1, $id2) 
    {
        if (Task::where('t_id', $id1)->exists()) {
            $task = Task::where([
            ['t_id', '=', $id1],
            ['a_id', '=', $id2]
        ])->get()->toJson(JSON_PRETTY_PRINT);
        return response($task, 200);
        } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
          }

    }
    

    public function updatetasks($id1, $id2, Request $request)
    {
        if ( Task::where([ ['t_id', '=', $id1], ['a_id', '=', $id2] ]) ) {
            $task = Task::where('t_id', $id1)->where('a_id', $id2)
            ->update(['titlle' => $request->title, 
                      'description' => $request->description,
                      'status' => $request->status
                    ]);
            return response()->json([
                "id" => $id1,
                "title" =>$request->title,
                "description"=>$request->description,
                "assignee_id"=>$id2,
                "status"=>$request->status
            ], 200);
        } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
          }
    }
}
