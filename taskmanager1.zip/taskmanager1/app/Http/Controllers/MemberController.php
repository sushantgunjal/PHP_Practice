<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Member;
use App\Models\Task;
use Illuminate\Support\Str;

class MemberController extends Controller
{
    //
    public function store($id, Request $request)
    {
        if (Team::where('id', $id)->exists()) {
            if (Member::where('email', $request->email)->exists()) {
                return response()->json([
                    "message" => "Email already associated with a team member"
                  ], 200);
            }
            else {
                $member = Member::create([
                    't_id' => $id,
                    'm_id' => Str::uuid(),
                    'name' =>$request->name,
                    'email' =>$request->email,
                ]);
                return response()->json($member, 201);
            }
        } 
        else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
        }
    }

    public function show($t_id)
    {
        if (Member::where('t_id', $t_id)->exists()) {
            //$team = Team::where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
            $team = Member::select('m_id','name', 'email')->where('t_id', $t_id)->get()->toJson(JSON_PRETTY_PRINT);
            return response($team, 200);
          } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
          }
        //return $team;
    }

    public function deleteMembers($id1, $id2)
    {
        if ( Member::where([ ['t_id', '=', $id1], ['m_id', '=', $id2] ]) ->exists() ) {
            if ( Task::where([ ['t_id', '=', $id1], ['a_id', '=', $id2] ]) ->exists() ) {
                return response()->json(["message" => 
                "Member cannot be deleted, please reassign all tasks from this member to someone else before trying again"
                ]);
            }
            else {
                $Member = Member::where('t_id', $id1)->where('m_id', $id2)->delete();
                return response()->json([
                    "message" => "records deleted"
                  ], 202);
            }
        } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
        }

    }
}
