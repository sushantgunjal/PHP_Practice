<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Team;
use Illuminate\Support\Str;

class TeamController extends Controller
{
    //
    public function index()
    {
        //return Team::all();
        return response()->json(Team::get(), 200);
    }

    public function show($id)
    {
        if (Team::where('id', $id)->exists()) {
            //$team = Team::where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
            $team = Team::select('id','name')->where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
            return response($team, 200);
          } else {
            return response()->json([
              "message" => "ID not found"
            ], 404);
          }
        //return $team;
    }

    public function store(Request $request)
    {
        //$uuid = Str::uuid()->toString();
        $team = Team::create([
            'id' => Str::uuid(),
            'name' =>$request->name,
        ]);
        //$team = Team::create($request->all());

        return response()->json($team, 201);
    }

    public function update(Request $request, Team $team)
    {
        $team->update($request->all());

        return response()->json($team, 200);
    }

    public function delete(Team $team)
    {
        $team->delete();

        return response()->json(null, 204);
    }
}
