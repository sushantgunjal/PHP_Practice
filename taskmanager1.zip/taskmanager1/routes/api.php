<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Team;
use App\Models\Member;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\TaskController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/* Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
}); */

Route::get('teams',[TeamController::class, 'index']);
Route::get('teams/{id}',[TeamController::class, 'show']);
//Route::get('teams/{id}', 'TeamController@show');
Route::post('teams',[TeamController::class, 'store']);
Route::post('teams/{id}/member',[MemberController::class, 'store']);
Route::get('teams/id/member',[MemberController::class, 'show']);
Route::post('teams/{id}/tasks',[TaskController::class, 'store']);
Route::get('teams/{id}/tasks',[TaskController::class, 'show']);
Route::get('teams/{id}/tasks',[TaskController::class, 'show']);
Route::get('teams/{id1}/members/{id2}/tasks',[TaskController::class, 'showtaskformembers']);
Route::patch('teams/{id1}/tasks/{id2}',[TaskController::class, 'updatetasks']);
//Route::delete('teams/{id1}/member/{id2}', 'TeamController@delete');
Route::delete('teams/{id1}/members/{id2}',[MemberController::class, 'deleteMembers']);
//Route::delete('teams/{id}', 'TeamController@delete');
